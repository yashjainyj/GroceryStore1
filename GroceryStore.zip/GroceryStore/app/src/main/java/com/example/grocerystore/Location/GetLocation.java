package com.example.grocerystore.Location;

import android.Manifest;
import android.app.Dialog;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.example.grocerystore.R;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;

public class GetLocation extends AppCompatActivity {
    private static final String TAG = "GetLocation";
    private static final int ERROR_DIALOG_REQUEST_ = 9001;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 101;
    public static final String FINE_LOCATION = Manifest.permission.ACCESS_FINE_LOCATION;
    public static final String COARSE_LOCATION = Manifest.permission.ACCESS_COARSE_LOCATION;
    public boolean mLoactionPermissionGranted = false;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.get_location);

        //getLocationPermission();

    }

//    private void getLocationPermission(){
//        String permission[] = {Manifest.permission.ACCESS_FINE_LOCATION,
//        Manifest.permission.ACCESS_COARSE_LOCATION};
//        if(ContextCompat.checkSelfPermission(this.getApplicationContext(),FINE_LOCATION)== PackageManager.PERMISSION_GRANTED)
//        {
//            if(ContextCompat.checkSelfPermission(this.getApplicationContext(),COARSE_LOCATION)== PackageManager.PERMISSION_GRANTED)
//            {
//                mLoactionPermissionGranted = true;
//            }
//            else {
//                ActivityCompat.requestPermissions(this,permission,LOCATION_PERMISSION_REQUEST_CODE);
//            }
//        }
//    }
//
//    @Override
//    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
//        mLoactionPermissionGranted=false;
//        switch (requestCode)
//        {
//            case LOCATION_PERMISSION_REQUEST_CODE:
////                if(grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED)
////                {
////                    mLoactionPermissionGranted=true;
////                }
//
//                if(grantResults.length>0)
//                {
//                    for(int i=0;i<grantResults.length;i++)
//                    {
//                        if(grantResults[i]==PackageManager.PERMISSION_GRANTED)
//                        {
//                            mLoactionPermissionGranted=false;
//                            return;
//                        }
//                    }
//                    mLoactionPermissionGranted = true;
//                }
//        }
//
//    }
//
//    public boolean isServiceOK(){
//        Log.d(TAG,"is Service ok : Checking version");
//        int available  = GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(GetLocation.this);
//        if(available== ConnectionResult.SUCCESS)
//        {
//            Log.d(TAG,"Every thing is OK");
//            return true;
//        }
//        else if(GoogleApiAvailability.getInstance().isUserResolvableError(available))
//        {
//            Log.d(TAG,"Error occured but we can fix it");
//            Dialog dialog = GoogleApiAvailability.getInstance().getErrorDialog(GetLocation.this,available,ERROR_DIALOG_REQUEST_);
//            dialog.show();
//        }
//        else
//        {
//            Log.d(TAG,"Can not resolve error");
//        }
//        return  false;
//    }
}
